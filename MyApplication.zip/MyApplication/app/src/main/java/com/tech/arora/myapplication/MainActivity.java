package com.tech.arora.myapplication;

import android.os.Bundle;
import android.support.v7.app.AlertController.RecycleListView;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity implements Main2Activity{
    EditText summ;
RecycleListView
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    summ=findViewById(R.id.cellEdit);
    }

    @Override
    public void total(int total, int num) {

    }
}


