package com.tech.arora.myapplication;

interface Main2Activity{
    void total(int total,int num);
}
